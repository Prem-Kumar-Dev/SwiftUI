//
//  GridApp.swift
//  Grid
//
//  Created by Prem Kumar on 04/02/26.
//

import SwiftUI

@main
struct GridApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
